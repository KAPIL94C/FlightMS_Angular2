package org.cap.flightmgt.flightms.exceptions;

public class FlightNotFoundException extends RuntimeException {
	
	public FlightNotFoundException(String msg) {
		super(msg);
	}

}
