package org.cap.empmgt;

import javax.persistence.EntityManager;

import org.cap.flightmgt.flightms.entities.Flight;
import org.cap.flightmgt.flightms.service.FlightServiceImpl;
import org.cap.flightmgt.flightms.service.IFlightService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import antlr.collections.List;

@SpringBootTest
@DataJpaTest// for jpa tests
@ExtendWith(SpringExtension.class)// integrate spring test framework with junit5
@Import(FlightServiceImpl.class)
class EmployeeManagementApplicationTests {
	
	@Autowired
    private IFlightService flightService;

    @Autowired
    private EntityManager entityManager;
    
    /**
     * case when room does not exist in database before
     */
    
    @Test
    public void testSaveRoom_1() {
    	
        String flightModel="AB200";
        String flightName="Air India";
        int seatCapacity = 200;
        Flight  flight=new Flight();
        flight.setCarrierName(flightName);
        flight.setFlightModel(flightModel);
        flight.setSeatCapacity(seatCapacity);
        Flight result = flightService.addFlight(flight);
        List fetched =  (List) entityManager.createQuery("from flights").getResultList();
//     
    }
    
    

	@Test
	void contextLoads() {
	}

}
